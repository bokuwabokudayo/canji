#!/usr/bin/env python
# -*- coding: utf-8 -*-

#import types
import uuid
from google.appengine.ext import ndb, blobstore
from google.appengine.api import images


DEFAULT_THUMBNAIL_HEIGHT = 200
DEFAULT_THUMBNAIL_WIDTH = 200
NUMBERER_OF_THUMBNAIL = 5

class Men(ndb.Model):
	_use_cache = False
	_use_memcache = False
	nickname = ndb.StringProperty(indexed=False)#ニックネーム
	residence = ndb.IntegerProperty(default=0, indexed=False)#出身地
	age = ndb.IntegerProperty(default=0, indexed=False)#年齢 from FB
	number_of_facebook_friends = ndb.IntegerProperty(default=0, indexed=False)#FBの友達
	height = ndb.IntegerProperty(default=0, indexed=False)#身長
	weight = ndb.IntegerProperty(default=0, indexed=False)#体型
	job = ndb.IntegerProperty(default=0, indexed=False)#職業
	job_title = ndb.StringProperty(indexed=False)#職業名###
	income = ndb.IntegerProperty(default=0, indexed=False)#年収
	education = ndb.IntegerProperty(default=0, indexed=False)#学歴
	school = ndb.StringProperty(indexed=False)#学校名###
	drink = ndb.IntegerProperty(default=0, indexed=False)#すきなお酒
	kind_of_drink = ndb.IntegerProperty(default=0, indexed=False)#すきなお酒######
	tabaco = ndb.IntegerProperty(default=0, indexed=False)#タバコ
	hobby = ndb.IntegerProperty(repeated=True)#趣味###
	appeal = ndb.StringProperty(indexed=False)#アピール自由記述
	fashion = ndb.IntegerProperty(default=0, indexed=False)#ファッション
	party_level = ndb.IntegerProperty(default=0, indexed=False)#合コン経験数
	party_character = ndb.IntegerProperty(default=0, indexed=False)#合コンでのキャラクター
	party_appeal = ndb.StringProperty(indexed=False)#合コンアピール
	releation_of_friends = ndb.IntegerProperty(default=0, indexed=False)#友達との関係
	age_of_friends = ndb.IntegerProperty(default=0, indexed=False)#友達の年代
	caracter_of_frineds = ndb.IntegerProperty(default=0, indexed=False)#友達のキャラクター
	date = ndb.IntegerProperty(indexed=False, repeated=True)#希望日###
	day = ndb.IntegerProperty(indexed=False, repeated=True)#希望曜日
	hour = ndb.IntegerProperty(default=0, indexed=False)#希望開始時間
	area = ndb.IntegerProperty(default=0, indexed=False)#希望都道府県
	place = ndb.IntegerProperty(indexed=False, repeated=True)#希望都市
	store = ndb.IntegerProperty(default=0, indexed=False)#希望お店
	people = ndb.IntegerProperty(default=0, indexed=False)#希望人数
	money = ndb.IntegerProperty(default=0, indexed=False)#お金
	atmosphere = ndb.IntegerProperty(default=0, indexed=False)#希望する合コンの雰囲気
	blob_key = ndb.BlobKeyProperty(indexed=False, repeated=True)
	thumbnail = ndb.BlobProperty(repeated=True)
	login = ndb.DateTimeProperty(auto_now_add=True)#ログイン時間##############後でTODO
	created_at = ndb.DateTimeProperty(auto_now_add=True)

	# @classmethod
	# def init():
		# man_blob_key = []
		# man_thumbnail = []
		# man.blob_key = man_blob_key
		# man.thumbnail = man_thumbnail
		# man.put()

	#@staticmethod
	@classmethod
	def insert_thumbnail(cls, _blob):
		unique_id = str(uuid.uuid4().int)[:8]
		img = images.Image(blob_key=_blob.key())
		img.resize(height=DEFAULT_THUMBNAIL_HEIGHT, width=DEFAULT_THUMBNAIL_WIDTH)
		thumbnail = img.execute_transforms(output_encoding=images.PNG)
		man = cls(
			id=unique_id,
			)
		man.blob_key.append(_blob.key())
		man.thumbnail.append(thumbnail)
		man.put()
		return man


	# 合コン申し込みをした人
	# 合コン申し込みをしてくれた人 len(list)
	# 実績、合コンをした人数

	# この人が見た人#足あと自分 りぴーと　ツルー
	# この人を見た人#足あと相手

	# 合コンをした人からのレビュー　文章