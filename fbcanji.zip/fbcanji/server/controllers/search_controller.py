#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, re
import urllib
import webapp2
import jinja2
from datetime import datetime
from google.appengine.ext import ndb, blobstore 
from google.appengine.ext.webapp import blobstore_handlers
from google.appengine.api import images
from view_helper import JINJA_ENV
from enums import Dic
from server.models.canji_model import Men


class BaseHandler(webapp2.RequestHandler):
    @webapp2.cached_property
    def jinja2(self):
        return jinja2.get_jinja2(app=self.app)

    def render_template(
        self,
        filename,
        template_values,
        **template_args):
        template = JINJA_ENV.get_template(filename)
        self.response.out.write(template.render(template_values))


# class Demo(BaseHandler):
#     def get(self):
        # self.response.write(JINJA_ENV.get_template('demo.html').render({}))


class SearchHandler(webapp2.RequestHandler):
    def get(self):
        # アップロード用のURLの取得。アップロードに成功したら/uploadに移動させる
        upload_url = blobstore.create_upload_url('/upload')
        
        files = blobstore.BlobInfo.all()
        #fil = Men.get_by_id('31218682')
        self.response.write(JINJA_ENV.get_template('test.html').render({
            'upload_url':upload_url,
            'files':files,
            # 'fil':fil,
            }))

class ProfileHandler(BaseHandler):
    def get(self, _url, _m_id, _w_id):
        if re.search(r'/m/\d+', _url):
            user = Men.get_by_id(_m_id)
        elif re.search(r'/w/\d+', _url):
            user = Women.get_by_id(_w_id)
        else:
            self.redirect('/')
        dic = Dic()
        self.response.write(JINJA_ENV.get_template('profile.html').render({
            'url': _url,
            'user': user,
            'residence': dic.residence[user.residence][0],
            }))

class EditProfileHandler(BaseHandler):
    def get(self, _url, _m_id, _w_id):
        if re.search(r'/m/\d+', _url):
            user = Men.get_by_id(_m_id)
        elif re.search(r'/w/\d+', _url):
            user = Women.get_by_id(_w_id)
        dic = Dic()
        residence = dic.get_residence()
        residence[user.residence][1] = 'selected'
        height = dic.get_height()
        height[user.height][1] = 'selected'
        weight = dic.get_weight()
        weight[user.weight][1] = 'selected'
        self.response.write(JINJA_ENV.get_template('edit_profile.html').render({
            'url': _url,
            'user': user,
            'residence': residence,
            'age': user.age,
            'number_of_facebook_friends': user.number_of_facebook_friends,
            'height': height,
            'weight': weight,
            }))
    
    def post(self, _url, _m_id, _w_id):
        if re.search(r'/m/\d+', _url):
            user = Men.get_by_id(_m_id)
        elif re.search(r'/w/\d+', _url):
            user = Women.get_by_id(_w_id)
        else:
            self.redirect('%s' % _url)
        user.nickname = self.request.get('nickname')
        user.residence = int(self.request.get('residence'))
        user.height = int(self.request.get('height'))
        user.weight = int(self.request.get('weight'))
        # user.job = self.request.get('job')
        # user.income = self.request.get('income')
        # user.education = self.request.get('education')
        # user.drink = self.request.get('drink')
        # user.tabaco = self.request.get('tabaco')
        # user.appeal = self.request.get('appeal')
        # user.party_level = self.request.get('party_level')
        # user.party_character = self.request.get('party_character')
        # user.party_appeal = self.request.get('party_appeal')
        # user.releation_of_friends = self.request.get('releation_of_friends')
        # user.age_of_friends = self.request.get('age_of_friends')
        # user.caracter_of_frineds = self.request.get('caracter_of_frineds')
        # user.days = self.request.get('days')
        # user.hours = self.request.get('hours')
        # user.areas = self.request.get('areas')
        # user.places = self.request.get('places')
        # user.stores = self.request.get('stores')
        # user.people = self.request.get('people')
        user.put()
        self.redirect('%s' % _url.replace('/edit', ''))



class UploadHandler(blobstore_handlers.BlobstoreUploadHandler):
    def post(self):
        upload_files = self.get_uploads('upload_file')
        blob_info = upload_files[0]
        if upload_files:
            Men.insert_thumbnail(blob_info)
        self.redirect('/serve/%s' % blob_info.key())


class ServeHandler(blobstore_handlers.BlobstoreDownloadHandler):
    def get(self, blob_key):
        blob_key = str(urllib.unquote(blob_key))
        blob_info = blobstore.BlobInfo.get(blob_key)
        self.send_blob(blob_info)


class ThumbnailHandler(webapp2.RequestHandler):
    def get(self, _url, _m_id, _m_thumb_idx, _w_id, _w_thumb_idx):
        target = Men.get_by_id(_m_id)
        print target.blob_key[0]
        if target is None:
            self.error(404)
            self.response.write("404 No Image Error!")
        else:
            self.response.headers['Content-Type'] = 'image/png'
            self.response.write(target.thumbnail[0])

# class ThumbnailHandler(webapp2.RequestHandler):
#     def get(self, sex, m_key_name, m_thumb_no, w_key_name, w_thumb_no):
#         """Serves an image of a particular meme.
#         Raises a 404 error when entity not found.
#         Args:
#             mode: 'image' or 'thumbnail', extracted from the URL path.
#             meme_id: id of Meme entity extracted from the URL path.
#         """
#         key_name = '31218682'
#         mode = 'iamge'
#         if re.search(r'/thumb/m=\d+', sex):
#             print "man"
#         target = Men.get_by_id(key_name)
#         if target is None:
#             self.error(404)
#             self.response.write("404 No Image Error!")
#         self.response.headers['Content-Type'] = 'image/png'
#         if mode == 'image':
#             self.response.write(target.thumbnail[0])
#         else:
#             self.response.write(target.thumbnail[0])