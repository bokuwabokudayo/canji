##
# @file    main.py
# @author  Hidenonu Hashikami
# @date    2014/01/27
#
# Copyright(C) 2014 hhashikami All Rights Reserved.
#
import webapp2
from server.controllers.search_controller import SearchHandler, ProfileHandler, EditProfileHandler, UploadHandler, ServeHandler, ThumbnailHandler


app = webapp2.WSGIApplication([
        ('/', SearchHandler),
        ('(/m/([^/]+)?|/w/([^/]+)?)', ProfileHandler),
        ('(/m/([^/]+)?/edit|/w/([^/]+)?/edit)', EditProfileHandler),
        ('/upload', UploadHandler),
        ('/serve/([^/]+)?', ServeHandler),
        # ('/thumb/k=([^/]+)?&t=([^/]+)?', ThumbnailHandler),
        ('(/m/([^/]+)?/thumb_idx=(\d+)|/w/([^/]+)?/thumb_idx=(\d+))', ThumbnailHandler),
        ],
        debug=True)